import {bind} from 'decko';

class Login {
    constructor(element) {
        this.main = document.querySelector('.main');
        this.btn = element.querySelector('.login__btn');
        // this.form = element.querySelector('.login__form');
        // this.email = element.querySelector('.login__email');
        // this.pass = element.querySelector('.login__password');
        // this.btnLog = element.querySelector('.login__button-log');
        // this.btnReg = element.querySelector('.login__button-reg');
        // this.email.addEventListener('keyup', this.checkEmail);
        // this.pass.addEventListener('keyup', this.checkPassword);
        // this.btnLog.addEventListener('click', this.clickBtnLog);
        // this.btnReg.addEventListener('click', this.clickBtnReg);
        this.btn.addEventListener('click', this.openModal);
    }

    @bind
    openModal() {
        this.shadow = document.createElement("div");
        this.shadow.classList.add('login__shadow');
        this.shadow.addEventListener('click', this.closeModal);
        this.main.appendChild(this.shadow);
        this.createGrid();
    }

    @bind
    closeModal() {
        this.main.removeChild(this.shadow);
    }

    @bind
    createGrid() {
        this.grid = document.createElement("div");
        this.grid.classList.add('login__grid');
        this.shadow.appendChild(this.grid);
        this.grid.addEventListener('click', function (e) { e.stopPropagation(); });
        this.createEmail();
        this.createPassword();
        this.createBtnLogin();
        this.createBtnRegister();
    }

    @bind
    createBtnRegister() {
        this.btnReg = document.createElement("input");
        this.btnReg.classList.add('login__btn-reg');
        this.btnReg.type = 'submit';
        this.btnReg.value = 'Register';
        this.btnReg.disabled = true;
        this.grid.appendChild(this.btnReg);
        this.btnReg.addEventListener('click', this.clickBtnReg);
    }

    @bind
    createBtnLogin() {
        this.btnLog = document.createElement("input");
        this.btnLog.classList.add('login__btn-log');
        this.btnLog.type = 'submit';
        this.btnLog.value = 'Sign in';
        this.btnLog.disabled = true;
        this.grid.appendChild(this.btnLog);
        this.btnLog.addEventListener('click', this.clickBtnLog);
    }

    @bind
    createPassword() {
        this.pass = document.createElement("input");
        this.pass.classList.add('login__password');
        this.pass.placeholder = 'password';
        this.pass.type = 'password';
        this.pass.name = 'password';
        this.grid.appendChild(this.pass);
        this.pass.addEventListener('keyup', this.checkPassword);
    }

    @bind
    createEmail() {
        this.email = document.createElement("input");
        this.email.classList.add('login__email');
        this.email.placeholder = 'e-mail';
        this.email.type = 'text';
        this.email.name = 'email';
        this.grid.appendChild(this.email);
        this.email.addEventListener('keyup', this.checkEmail);
    }

    // async httpPost() {
    //     await fetch('article', { method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify({ title: this.title.value, content: this.content.value})})
    //     .then(function (response) {
    //         console.log(response.status);
    //     });
    //     this.modal.classList.toggle("modalAddArticle__open");
    //     this.modalOverlay.classList.toggle("overlayAddArticle__open");
    // }  

    @bind
    clickBtnLog() {
        // this.form.action = "/login";
        this.modal = document.createElement("div");
        this.modal.style.backgroundColor = "rgba(0,0,0,0.5)";
        this.modal.style.width = "100%";
        this.modal.style.height = "100%";
        this.modal.style.position = "absolute";
        this.modal.style.top = "0px";
        this.modal.style.left = "0px";
        let shadow = document.querySelector('.main');
        shadow.appendChild(this.modal);
    }

    @bind
    clickBtnReg() {
        this.form.action = "doc/register";        
    }

    @bind
    checkEmail(){
        var regExpToCheck = new RegExp("^(([^<>()[\\]\\\\.,;:\\s@\\']+(\\.[^<>()[\\]\\\\.,;:\\s@\\']+)*)|(\\'.+\\'))@((\\[[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\])|(([a-zA-Z\\-0-9]+\\.)+[a-zA-Z]{2,}))$");
        this.checkRegExp(this.email, regExpToCheck);
    }

    @bind
    checkPassword(){
        var regExpToCheck = new RegExp("^([a-zA-Z0-9_-]){3,10}$");
        this.checkRegExp(this.pass, regExpToCheck);
    }

    checkRegExp(element, regExpToCheck) {
        if (regExpToCheck.test(element.value)) {
            element.classList.remove("error");
            element.check = true;
        }
        else {
            element.classList.add("error");
            element.check = false;
        }
        this.checkButton();
    }

    @bind
    checkButton() {
        if (this.email.check && this.pass.check) {
            this.btnLog.disabled = false;
            this.btnReg.disabled = false;
        }
        else {
            this.btnLog.disabled = true;
            this.btnReg.disabled = true;
        }
    }
}

var loginElement = document.querySelector('.login');
if (loginElement) new Login(loginElement);